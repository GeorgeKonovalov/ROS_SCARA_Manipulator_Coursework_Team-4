from launch import LaunchDescription
from launch_ros.actions import Node

# This launch file starts all nodes required for Task 1:
# - mouse publisher
# - keyboard publisher
# - filter node
# - GUI subscriber

def generate_launch_description():
    return LaunchDescription([

        # Mouse publisher node (reads cursor position)
        Node(
            package='task1_pkg',
            executable='mouse_publisher.py',
            name='mouse_publisher',
            output='screen'
        ),

        # Keyboard publisher node (reads key presses)
        Node(
            package='task1_pkg',
            executable='keyboard_publisher.py',
            name='keyboard_publisher',
            output='screen'
        ),

        # Filter node (applies moving average smoothing)
        Node(
            package='task1_pkg',
            executable='filter_node.py',
            name='filter_node',
            output='screen'
        ),

        # GUI node (main interface and logic)
        Node(
            package='task1_pkg',
            executable='gui_subscriber.py',
            name='gui_node',
            output='screen'
        ),
    ])