#!/usr/bin/env python3

# This node listens to keyboard input and publishes pressed keys
# using std_msgs/String

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from pynput import keyboard

class KeyboardPublisher(Node):
    def __init__(self):
        super().__init__('keyboard_publisher')

        # Publisher sends key presses to this topic
        self.publisher = self.create_publisher(String, '/keyboard_input', 10)

        # Start keyboard listener in background
        listener = keyboard.Listener(on_press=self.on_press)
        listener.start()

    def on_press(self, key):
        # Try to get character (ignore special keys like shift)
        try:
            msg = String()
            msg.data = key.char

            # Publish key
            self.publisher.publish(msg)
        except:
            # Ignore non-character keys
            pass


def main(args=None):
    rclpy.init(args=args)

    node = KeyboardPublisher()
    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()