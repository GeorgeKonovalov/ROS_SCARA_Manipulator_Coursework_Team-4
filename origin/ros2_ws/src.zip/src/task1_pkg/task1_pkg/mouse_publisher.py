#!/usr/bin/env python3

# This node reads the current mouse position from the system
# and publishes it as a ROS2 message (geometry_msgs/Point)

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
import pyautogui

class MousePublisher(Node):
    def __init__(self):
        super().__init__('mouse_publisher')

        # Publisher sends mouse position on this topic
        self.publisher = self.create_publisher(Point, '/mouse_position', 10)

        # Timer runs every 0.02 seconds (~50 Hz)
        self.timer = self.create_timer(0.02, self.publish_mouse)

    def publish_mouse(self):
        # Get current mouse position from OS
        x, y = pyautogui.position()

        # Create message and assign values
        msg = Point()
        msg.x = float(x)
        msg.y = float(y)

        # Publish message
        self.publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)

    node = MousePublisher()
    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()