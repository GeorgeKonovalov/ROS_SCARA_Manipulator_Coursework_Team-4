#!/usr/bin/env python3

# Main GUI node.
# Subscribes to mouse and keyboard topics, displays cursor,
# and applies logic such as boundaries, locking, and filtering mode.

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
from std_msgs.msg import String
import tkinter as tk


class GUINode(Node):
    def __init__(self):
        super().__init__('gui_node')

        # Subscribe to raw mouse data
        self.raw_sub = self.create_subscription(
            Point, '/mouse_position', self.raw_callback, 10)

        # Subscribe to filtered mouse data
        self.filtered_sub = self.create_subscription(
            Point, '/filtered_mouse', self.filtered_callback, 10)

        # Subscribe to keyboard input
        self.key_sub = self.create_subscription(
            String, '/keyboard_input', self.key_callback, 10)

        # Current cursor position
        self.mouse_x = 0
        self.mouse_y = 0

        # Lock state (used for freeze behaviour)
        self.locked = False

        # Toggle between raw and filtered input
        self.use_filtered = False

        # Create GUI window
        self.window = tk.Tk()
        self.window.title("ROS Task 1 GUI")

        # Create drawing canvas
        self.canvas = tk.Canvas(self.window, width=600, height=600, bg="black")
        self.canvas.pack()

        # Bind left mouse click to toggle filtering
        self.canvas.bind("<Button-1>", self.mouse_click)

        # Define working area (robot box)
        self.box_size = 200
        self.box_x = 300
        self.box_y = 300

        # Draw box
        self.box = self.canvas.create_rectangle(
            self.box_x - self.box_size // 2,
            self.box_y - self.box_size // 2,
            self.box_x + self.box_size // 2,
            self.box_y + self.box_size // 2,
            outline='red',
            width=3
        )

        # Draw cursor (white dot)
        self.cursor = self.canvas.create_oval(0, 0, 5, 5, fill="white")

        # Add text to show current mode
        self.mode_text = self.canvas.create_text(
            300, 20,
            text="Mode: RAW",
            fill="white",
            font=("Arial", 14)
        )

        # Start GUI update loop
        self.update_gui()

    def raw_callback(self, msg):
        # Update position only if raw mode is active
        if not self.use_filtered and not self.locked:
            self.mouse_x = msg.x / 3
            self.mouse_y = msg.y / 3

    def filtered_callback(self, msg):
        # Update position only if filtered mode is active
        if self.use_filtered and not self.locked:
            self.mouse_x = msg.x / 3
            self.mouse_y = msg.y / 3

    def key_callback(self, msg):
        key = msg.data

        # Lock system
        if key == 'l':
            self.locked = True
            self.canvas.itemconfig(self.box, outline='purple')
            self.window.after(10000, self.unlock)

        # Pickup action
        elif key == 'p':
            if self.is_inside():
                self.locked = True
                self.canvas.itemconfig(self.box, outline='blue')
                self.window.after(10000, self.unlock)
            else:
                print("ERROR: Cursor outside box")

        # Toggle filtering using keyboard
        elif key == 'f':
            self.toggle_filter("keyboard")

    def mouse_click(self, event):
        # Toggle filtering using mouse click
        self.toggle_filter("mouse")

    def toggle_filter(self, source):
        # Switch between raw and filtered modes
        self.use_filtered = not self.use_filtered

        if self.use_filtered:
            print(f"Switched to FILTERED mode ({source})")
        else:
            print(f"Switched to RAW mode ({source})")

    def unlock(self):
        # Unlock system after delay
        self.locked = False

    def is_inside(self):
        # Check if cursor is inside the working area
        left = self.box_x - self.box_size // 2
        right = self.box_x + self.box_size // 2
        top = self.box_y - self.box_size // 2
        bottom = self.box_y + self.box_size // 2

        return left <= self.mouse_x <= right and top <= self.mouse_y <= bottom

    def update_gui(self):
        # Move cursor on screen
        self.canvas.coords(
            self.cursor,
            self.mouse_x - 3, self.mouse_y - 3,
            self.mouse_x + 3, self.mouse_y + 3
        )

        # Update mode text
        if self.use_filtered:
            self.canvas.itemconfig(self.mode_text, text="Mode: FILTERED")
        else:
            self.canvas.itemconfig(self.mode_text, text="Mode: RAW")

        # Update box colour depending on state
        if not self.locked:
            if self.is_inside():
                if self.use_filtered:
                    self.canvas.itemconfig(self.box, outline='cyan')  # filtered mode
                else:
                    self.canvas.itemconfig(self.box, outline='green')  # raw mode
            else:
                self.canvas.itemconfig(self.box, outline='red')

        # Repeat update loop
        self.window.after(20, self.update_gui)


def main(args=None):
    rclpy.init(args=args)

    node = GUINode()

    # Run both ROS and GUI loop together
    while rclpy.ok():
        rclpy.spin_once(node)
        node.window.update()

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()