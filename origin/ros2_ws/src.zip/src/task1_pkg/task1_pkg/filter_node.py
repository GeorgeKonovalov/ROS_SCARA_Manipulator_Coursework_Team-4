#!/usr/bin/env python3

# This node subscribes to raw mouse position data and applies
# a moving average filter to smooth the movement.
# The filtered result is then published to a separate topic.

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point


class FilterNode(Node):
    def __init__(self):
        super().__init__('filter_node')

        # Subscribe to raw mouse data
        self.subscription = self.create_subscription(
            Point,
            '/mouse_position',
            self.callback,
            10
        )

        # Publisher for filtered (smoothed) mouse data
        self.publisher = self.create_publisher(Point, '/filtered_mouse', 10)

        # Number of samples used in moving average
        # Larger value = smoother but more delay
        self.window_size = 20

        # Lists to store recent x and y values
        self.x_values = []
        self.y_values = []

    def callback(self, msg):
        # Add new incoming values
        self.x_values.append(msg.x)
        self.y_values.append(msg.y)

        # Keep only the last "window_size" values
        if len(self.x_values) > self.window_size:
            self.x_values.pop(0)
            self.y_values.pop(0)

        # Compute moving average
        avg_x = sum(self.x_values) / len(self.x_values)
        avg_y = sum(self.y_values) / len(self.y_values)

        # Create and publish filtered message
        filtered_msg = Point()
        filtered_msg.x = avg_x
        filtered_msg.y = avg_y
        self.publisher.publish(filtered_msg)

        # Print debug info occasionally (not every frame to avoid spam)
        if len(self.x_values) == self.window_size:
            print(
                f"RAW: ({msg.x:.1f}, {msg.y:.1f}) "
                f"-> FILTERED: ({avg_x:.1f}, {avg_y:.1f})"
            )


def main(args=None):
    # Initialise ROS2
    rclpy.init(args=args)

    # Create node
    node = FilterNode()

    # Keep node running
    rclpy.spin(node)

    # Clean shutdown
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()